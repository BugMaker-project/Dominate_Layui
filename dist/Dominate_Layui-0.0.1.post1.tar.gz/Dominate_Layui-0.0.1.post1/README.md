## Dominate_Layui
#### Author:Barry Liu
Thank you for using dominate_layui!<br><br>
It's a easy package for layui Devlopment.<br>
Now we have several JavaScript functions：<br>
- MassageBox(str)
- AlertBox(str)
- LoadsBox(style = null, Second)
- CloseBox(ObjBox)
- CloseAllBox(BoxType = null)
If you can use Layui,You can write your func at Init.js<br>
There are also several Python functions<br>
- class HTMLDocument
- linkInit(doc:HTMLDocument)
- FuncBtnAdd(doc:HTMLDocument,title:str,color:str="primary",radius:str="null",fluid:str="none",size:str="nr",onClick:str=None)
- LinkBtnAdd(doc:HTMLDocument,title:str,color:str="primary",radius:str="null",fluid:str="none",size:str="nr",href:str=None)
- render(doc:HTMLDocument,DocName:str)  
Always Upgrade.


